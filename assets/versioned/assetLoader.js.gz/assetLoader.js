// THIS FILE IS GENERATED; DO NOT MODIFY BY HAND.

const loadCss = (url) => {
  const linkElem = document.createElement("link");
  linkElem.rel = "stylesheet";
  linkElem.charset = "UTF-8";
  linkElem.href = url;
  document.body.append(linkElem);
};
const loadJs = (url, type) => {
  const scriptElem = document.createElement("script");
  scriptElem.charset = "UTF-8";
  scriptElem.src = url;
  if (type) {
    scriptElem.type = type
  }
  document.body.append(scriptElem);
};

window.__loadConsoleAssetsFromBasePath = (root) => {
const basePath = root.endsWith('/') ? root : root + '/';
loadCss(basePath + "styles.fc6f53a0f0dad8a8.css.gz");
loadJs(basePath + "runtime.d1f5e61950934305.js.gz", "module");
loadJs(basePath + "polyfills.dac9af8d8d28bb36.js.gz", "module");
loadJs(basePath + "styles.8cd54f3f26510679.js.gz", "module");
loadJs(basePath + "vendor.3b6b3376311b8c2d.js.gz", "module");
loadJs(basePath + "main.eba689e2ea8e2cf4.js.gz", "module");
}